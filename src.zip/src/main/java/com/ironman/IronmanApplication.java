package com.ironman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class IronmanApplication {
  public static void main(String[] args) {
    SpringApplication.run(IronmanApplication.class, args);
  }
}
